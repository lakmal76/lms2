# 📹 POLICE LMS v15 - VISUAL STEP-BY-STEP GUIDE

## STEP 1: EXTRACT ZIP FILE

### 🎬 Method 1: SSH Terminal (Linux/Mac/PowerShell)

```
╔════════════════════════════════════════════════════════════════╗
║ STEP 1: EXTRACT FILES TO WEB SERVER                           ║
╚════════════════════════════════════════════════════════════════╝

1. Open Terminal or SSH Client
   • Mac/Linux: Terminal app
   • Windows: PowerShell or PuTTY
   • Web: cPanel Terminal

2. Connect to Server (if not already connected)
   $ ssh your_username@your_server.com
   Password: [Enter your SSH password]

3. Navigate to Web Root
   $ cd /var/www/html
   
   Alternative paths:
   • cPanel: cd public_html
   • WordPress: cd /home/user/public_html
   • Custom: cd /your/custom/path

4. Extract ZIP File
   $ unzip police-lms-v15.zip
   
   Expected Output:
   ┌────────────────────────────────────────┐
   │ Archive: police-lms-v15.zip            │
   │  inflating: police-lms-v15/README.md   │
   │  inflating: police-lms-v15/auth/login.php   │
   │  ...                                   │
   │ creating: police-lms-v15/assets/css/  │
   └────────────────────────────────────────┘

5. Verify Extraction
   $ ls -la police-lms-v15/
   
   Expected Output:
   ┌──────────────────────────────────────────┐
   │ drwxr-xr-x  auth                         │
   │ drwxr-xr-x  config                       │
   │ drwxr-xr-x  assets                       │
   │ -rw-r--r--  dashboard.php                │
   │ -rw-r--r--  database_setup.sql           │
   │ -rw-r--r--  README.md                    │
   │ ...                                      │
   └──────────────────────────────────────────┘

✅ SUCCESS: Files are extracted!
```

### 🎬 Method 2: FTP File Manager

```
╔════════════════════════════════════════════════════════════════╗
║ USING FTP/FILE MANAGER TO EXTRACT                             ║
╚════════════════════════════════════════════════════════════════╝

1. Open FTP Client
   • FileZilla (Free)
   • WinSCP (Free)
   • Cyberduck (Mac)
   • Your hosting provider's built-in manager

2. Connect to Server
   ┌─────────────────────────────────────┐
   │ Host: your-server.com               │
   │ Username: your-ftp-username         │
   │ Password: your-ftp-password         │
   │ Port: 21 (or 22 for SFTP)          │
   │ [Connect]                           │
   └─────────────────────────────────────┘

3. Navigate to Web Root
   Left panel (Local): Where file is downloaded
   Right panel (Remote): /var/www/html or /public_html
   
   Click folder tree to expand
   Double-click folders to enter

4. Upload ZIP File
   Left panel: Browse to police-lms-v15.zip
   Right panel: Drag and drop to upload
   OR: Right-click → Upload
   
   Wait for "100% Complete" message

5. Extract on Server
   Right panel: Right-click police-lms-v15.zip
   Select: Extract or Decompress
   
   May take 30-60 seconds...
   
   ┌────────────────────────────────┐
   │ ████████████████████ 100%      │
   │ Extracting files...            │
   └────────────────────────────────┘

6. Verify
   Should see folder: police-lms-v15/
   Inside should be: auth, config, assets, etc.

✅ SUCCESS: Files are extracted!
```

---

## STEP 2: CREATE DATABASE

### 🎬 Method 1: Terminal (Recommended)

```
╔════════════════════════════════════════════════════════════════╗
║ STEP 2: CREATE DATABASE                                        ║
╚════════════════════════════════════════════════════════════════╝

1. Navigate to Extracted Folder
   $ cd /var/www/html/police-lms-v15
   $ pwd
   /var/www/html/police-lms-v15  ✅ Correct location

2. Run Database Setup Script
   $ mysql -u root -p < database_setup.sql
   
   You'll see:
   Enter password: [Type root password and press Enter]
   
   ⏳ Wait 2-3 seconds...
   
   Expected Output (last few lines):
   ┌──────────────────────────────┐
   │ Query OK, 0 rows affected    │
   │ Query OK, 0 rows affected    │
   │ Query OK, 0 rows affected    │
   │ Database migration completed │
   └──────────────────────────────┘

3. Verify Tables Created
   $ mysql -u root -p
   Enter password: [Type root password]
   
   At MySQL prompt (mysql>):
   mysql> USE police_lms;
   mysql> SHOW TABLES;
   
   Expected Output:
   ┌───────────────────────────────┐
   │ Tables_in_police_lms          │
   ├───────────────────────────────┤
   │ action_history                │
   │ divisions                     │
   │ leave_requests                │
   │ leave_types                   │
   │ stations                      │
   │ system_access_logs            │
   │ units                         │
   │ user_rank_history             │
   │ users                         │
   │ ... (more tables)             │
   └───────────────────────────────┘
   13 rows in set (0.00 sec)

4. Check Super Admin User
   mysql> SELECT id, nic, full_name FROM users;
   
   Expected Output:
   ┌────┬────────────┬───────────────────┐
   │ id │ nic        │ full_name         │
   ├────┼────────────┼───────────────────┤
   │ 1  │ 000000000V │ System Admin...   │
   └────┴────────────┴───────────────────┘

5. Exit MySQL
   mysql> EXIT;

✅ SUCCESS: Database created with all tables!
```

### 🎬 Method 2: phpMyAdmin (Web Interface)

```
╔════════════════════════════════════════════════════════════════╗
║ USING phpMyAdmin                                               ║
╚════════════════════════════════════════════════════════════════╝

1. Open phpMyAdmin
   URL: https://your-server.com/phpmyadmin
   (Or: cpanel → phpMyAdmin icon)

2. Login
   Username: root (or your MySQL user)
   Password: [Your MySQL password]
   [Login]

3. Create Database (if not exists)
   Left sidebar → [New]
   
   Database name: police_lms
   Collation: utf8mb4_unicode_ci
   [Create]

4. Import SQL File
   Click: police_lms database (on left)
   Tab: Import
   
   ┌──────────────────────────────┐
   │ [Choose File]                │
   │ Select: database_setup.sql   │
   │ [Import]                     │
   └──────────────────────────────┘
   
   Wait for success message...
   ✅ Import successful

5. Verify Tables
   Left sidebar: police_lms
   Should show: Tables (13)
   
   Expand to see:
   • action_history
   • divisions
   • leave_requests
   • stations
   • users
   • ... and more

✅ SUCCESS: Database created!
```

---

## STEP 3: CONFIGURE CREDENTIALS

### 🎬 Edit config/db.php

```
╔════════════════════════════════════════════════════════════════╗
║ STEP 3: CONFIGURE DATABASE CREDENTIALS                        ║
╚════════════════════════════════════════════════════════════════╝

1. Open File in Editor

   TERMINAL METHOD (Nano Editor):
   $ cd /var/www/html/police-lms-v15
   $ nano config/db.php
   
   FTP METHOD:
   • Navigate to /config/
   • Right-click db.php
   • Select "Edit"

2. Find These Lines (around line 5-8)
   ┌────────────────────────────────────────────┐
   │ $DB_HOST = 'localhost';                    │
   │ $DB_USER = 'police_lms_app';              │
   │ $DB_PASS = '';                            │
   │ $DB_NAME = 'police_lms';                  │
   └────────────────────────────────────────────┘

3. Update Credentials
   
   ❌ BEFORE:
   $DB_HOST = getenv(...) ?: 'localhost';
   $DB_USER = getenv(...) ?: 'police_lms_app';
   $DB_PASS = getenv(...) ?: '';
   $DB_NAME = getenv(...) ?: 'police_lms';

   ✅ AFTER (Example 1 - Local):
   $DB_HOST = 'localhost';
   $DB_USER = 'root';
   $DB_PASS = 'your_mysql_password';
   $DB_NAME = 'police_lms';

   ✅ AFTER (Example 2 - cPanel):
   $DB_HOST = 'localhost';
   $DB_USER = 'cpaneluser_lms';
   $DB_PASS = 'generated_password_123';
   $DB_NAME = 'cpaneluser_lms';

   ✅ AFTER (Example 3 - Remote):
   $DB_HOST = 'db.example.com';
   $DB_USER = 'remote_user';
   $DB_PASS = 'remote_password_456';
   $DB_NAME = 'police_lms';

4. Save Changes

   NANO EDITOR:
   Press Ctrl + X
   Press Y
   Press Enter

   TEXT EDITOR (FTP):
   Click Save button
   Confirm

✅ SUCCESS: Credentials configured!
```

---

## STEP 4: SET PERMISSIONS

### 🎬 Fix File Permissions

```
╔════════════════════════════════════════════════════════════════╗
║ STEP 4: SET FILE PERMISSIONS                                  ║
╚════════════════════════════════════════════════════════════════╝

1. Navigate to Installation
   $ cd /var/www/html/police-lms-v15

2. Set Permissions (Terminal)
   
   All files to readable (644):
   $ find . -type f -exec chmod 644 {} \;
   
   All directories to executable (755):
   $ find . -type d -exec chmod 755 {} \;
   
   Config files to secure (600):
   $ chmod 600 config/db.php
   $ chmod 600 config/auth.php
   $ chmod 600 config/security_headers.php

3. Verify Permissions
   $ ls -la config/db.php
   
   Should show:
   -rw------- (600 = only owner can read/write)
   ✅ CORRECT

   $ ls -la auth/login.php
   
   Should show:
   -rw-r--r-- (644 = owner read/write, others read)
   ✅ CORRECT

4. Alternative: FTP File Manager
   
   For each file/folder:
   • Right-click
   • Select "Permissions"
   • Set numeric value:
     - Folders: 755
     - Config files: 600
     - Other files: 644

✅ SUCCESS: Permissions are correct!
```

---

## STEP 5: FIRST LOGIN TEST

### 🎬 Test the System

```
╔════════════════════════════════════════════════════════════════╗
║ STEP 5: FIRST LOGIN                                           ║
╚════════════════════════════════════════════════════════════════╝

1. Open Browser
   Go to: https://your-domain.com/police-lms-v15/auth/login.php
   
   Replace "your-domain.com" with your actual domain

2. Login Page Should Display
   
   ┌─────────────────────────────────────┐
   │                                     │
   │      🔐 Police LMS                  │
   │    Leave Management System          │
   │                                     │
   │ NIC: [_________________]            │
   │ Password: [_________________]       │
   │ Security: [3 + 5 = __]             │
   │                                     │
   │  [Sign In]                          │
   │                                     │
   └─────────────────────────────────────┘

3. Enter Default Credentials
   
   NIC: 000000000V
   Password: password
   Security Code: [Solve the math, e.g., "8"]
   
   [Click Sign In]

4. Handle "Change Password" Page
   
   ┌─────────────────────────────────────┐
   │ 🔒 Change Password                  │
   │                                     │
   │ Current Password: [______]          │
   │ New Password: [______]              │
   │ Confirm Password: [______]          │
   │                                     │
   │ [Update Password]                   │
   └─────────────────────────────────────┘

   Enter:
   • Current: password
   • New: MySecurePass@123
   • Confirm: MySecurePass@123
   
   Password requirements:
   ✓ 8+ characters
   ✓ Uppercase letter (A-Z)
   ✓ Lowercase letter (a-z)
   ✓ Number (0-9)
   ✓ Special char (!@#$%^&*)
   
   [Click Update Password]

5. Dashboard Should Display
   
   ┌─────────────────────────────────────┐
   │ Welcome, System Administrator! ✅   │
   │                                     │
   │ [KPI Card] [KPI Card]              │
   │ [KPI Card] [KPI Card]              │
   │                                     │
   │ Upcoming Leaves                     │
   │ [No upcoming leaves]                │
   │                                     │
   │ Quick Actions                       │
   │ [Apply Leave] [My Status]           │
   │                                     │
   └─────────────────────────────────────┘

✅ SUCCESS: System is working!
```

---

## TROUBLESHOOTING QUICK REFERENCE

```
╔════════════════════════════════════════════════════════════════╗
║ QUICK FIXES FOR COMMON ISSUES                                 ║
╚════════════════════════════════════════════════════════════════╝

PROBLEM 1: "Database connection failed"
└─ SOLUTION:
   1. Check MySQL running: systemctl status mysql
   2. Verify credentials: cat config/db.php
   3. Test connection: mysql -u root -p -D police_lms
   4. Check password correct

PROBLEM 2: "Login failed - invalid credentials"
└─ SOLUTION:
   1. Verify user exists: mysql -u root -p
                          SELECT * FROM users;
   2. Check account status: should be 'ACTIVE'
   3. Reset password if needed

PROBLEM 3: "CSS not loading - page looks broken"
└─ SOLUTION:
   1. Clear browser cache: Ctrl+Shift+Delete
   2. Check file exists: ls -la assets/css/style.css
   3. Check permissions: chmod 644 assets/css/style.css
   4. Try different browser

PROBLEM 4: "Cannot access login page"
└─ SOLUTION:
   1. Check URL: should be /police-lms-v15/auth/login.php
   2. Check files extracted: ls -la police-lms-v15/
   3. Check permissions: chmod 755 police-lms-v15/

PROBLEM 5: "Session timeout"
└─ SOLUTION:
   1. Check session path: ls -la /var/lib/php/sessions/
   2. Fix permissions: chmod 1733 /var/lib/php/sessions/
   3. Increase timeout: edit php.ini session.gc_maxlifetime

Use tail command to check logs:
$ tail -50 /var/log/php-error.log
$ tail -50 /var/log/mysql/error.log
```

---

## INSTALLATION COMPLETE!

```
╔════════════════════════════════════════════════════════════════╗
║ ✅ INSTALLATION SUCCESSFUL                                    ║
╚════════════════════════════════════════════════════════════════╝

WHAT YOU'VE COMPLETED:
✅ Extracted files to web server
✅ Created database with all tables
✅ Configured database credentials
✅ Set correct file permissions
✅ Tested login and dashboard
✅ Changed default password

NEXT STEPS:
1. Create additional admin users
2. Configure backups
3. Train staff on the system
4. Monitor system performance
5. Go live!

YOUR SYSTEM IS READY FOR PRODUCTION! 🚀
```

---

**Version:** 15.0  
**Installation Date:** [Today]  
**Status:** ✅ Complete
