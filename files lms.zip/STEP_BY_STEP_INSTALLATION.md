# 🚀 POLICE LMS v15 - STEP-BY-STEP INSTALLATION GUIDE

## Table of Contents
1. [Pre-Installation Checklist](#pre-installation-checklist)
2. [Step 1: Extract Files](#step-1-extract-files)
3. [Step 2: Create Database](#step-2-create-database)
4. [Step 3: Configure Database Credentials](#step-3-configure-database-credentials)
5. [Step 4: Set File Permissions](#step-4-set-file-permissions)
6. [Step 5: Verify Installation](#step-5-verify-installation)
7. [Step 6: First Login](#step-6-first-login)
8. [Step 7: Post-Installation Setup](#step-7-post-installation-setup)
9. [Troubleshooting](#troubleshooting)

---

## PRE-INSTALLATION CHECKLIST

### ✅ Before You Start

Make sure you have:
- [ ] Server access (SSH or FTP)
- [ ] MySQL/MariaDB installed
- [ ] PHP 8.0+ installed
- [ ] Web server (Apache/Nginx) configured
- [ ] police-lms-v15.zip file downloaded
- [ ] Administrator access to MySQL
- [ ] Text editor (nano, vim, or file manager)

### ✅ System Requirements

**Minimum:**
- PHP 8.0+
- MySQL 5.7+
- 100 MB disk space
- 512 MB RAM

**Recommended:**
- PHP 8.2+
- MySQL 8.0+
- 500 MB disk space
- 2 GB RAM

---

## STEP 1: EXTRACT FILES

### Option A: Using SSH (Linux/Mac)

```bash
# 1. Connect to your server
ssh user@your-server.com

# 2. Navigate to web root
cd /var/www/html

# 3. Extract the ZIP file
unzip police-lms-v15.zip

# Expected output:
# creating: police-lms-v15/
# inflating: police-lms-v15/auth/login.php
# inflating: police-lms-v15/config/db.php
# ... (all files will be extracted)

# 4. Verify extraction
ls -la police-lms-v15/

# Expected output (should show these directories):
# drwxr-xr-x auth
# drwxr-xr-x config
# drwxr-xr-x assets
# -rw-r--r-- database_setup.sql
# -rw-r--r-- dashboard.php
# -rw-r--r-- README.md
# ... (and more files)

# 5. Optional: Remove the ZIP file
rm police-lms-v15.zip
```

### Option B: Using FTP/File Manager

1. **Connect to FTP:**
   - Open FTP client (FileZilla, WinSCP, etc.)
   - Enter server details:
     - Host: your-server.com
     - Username: your-ftp-user
     - Password: your-ftp-password
   - Port: 21 (or 22 for SFTP)

2. **Upload ZIP File:**
   - Navigate to `/var/www/html` or `/public_html`
   - Upload `police-lms-v15.zip`
   - Wait for upload to complete

3. **Extract on Server:**
   - Right-click `police-lms-v15.zip`
   - Select "Extract" or "Decompress"
   - Wait for extraction (may take 1-2 minutes)

4. **Verify:**
   - You should see `police-lms-v15` folder
   - Inside should be: `auth`, `config`, `assets`, `dashboard.php`, `database_setup.sql`, etc.

### Option C: Using cPanel (If Available)

1. **Upload via File Manager:**
   - Login to cPanel
   - Go to File Manager
   - Navigate to `public_html`
   - Upload `police-lms-v15.zip`

2. **Extract:**
   - Right-click on ZIP file
   - Click "Extract"
   - Confirm extraction

---

## STEP 2: CREATE DATABASE

### Method 1: Using SSH Command Line (Recommended)

```bash
# 1. Connect to your server
ssh user@your-server.com

# 2. Navigate to the extracted folder
cd /var/www/html/police-lms-v15

# 3. Run the database setup script
mysql -u root -p < database_setup.sql

# You'll be prompted for MySQL root password:
# Enter password: [type your root password and press Enter]

# Expected output (last line should say):
# Database migration completed successfully
```

### Method 2: Using MySQL Command Line

```bash
# 1. Connect to MySQL as root
mysql -u root -p

# You'll be prompted for password
# Enter password: [type password]

# 2. At MySQL prompt (mysql>), run:
SOURCE /var/www/html/police-lms-v15/database_setup.sql;

# Expected output:
# Query OK, 0 rows affected
# Query OK, 0 rows affected
# ... (multiple queries)
# Database migration completed successfully

# 3. Verify tables were created
SHOW TABLES;

# You should see these tables:
# +----------------------------------+
# | Tables_in_police_lms             |
# +----------------------------------+
# | action_history                   |
# | divisions                        |
# | leave_request_lieu_days          |
# | leave_requests                   |
# | leave_types                      |
# | lieu_leave_days                  |
# | station_group_users              |
# | stations                         |
# | system_access_logs               |
# | units                            |
# | user_rank_history                |
# | user_rank_history_audit          |
# | users                            |
# +----------------------------------+
# 13 rows in set

# 4. Exit MySQL
EXIT;
```

### Method 3: Using phpMyAdmin (If Available)

1. **Open phpMyAdmin:**
   - URL: `https://your-server.com/phpmyadmin`
   - Login with your MySQL credentials

2. **Create Database:**
   - Click "New" (or "Create Database")
   - Database name: `police_lms`
   - Collation: `utf8mb4_unicode_ci`
   - Click "Create"

3. **Import SQL File:**
   - Select the `police_lms` database
   - Click "Import" tab
   - Click "Choose File"
   - Select `database_setup.sql` from your computer
   - Click "Import"

4. **Verify:**
   - Should see success message
   - Click on `police_lms` database
   - Should see 13+ tables listed

---

## STEP 3: CONFIGURE DATABASE CREDENTIALS

### Step 3.1: Access the Configuration File

**Using SSH:**
```bash
# 1. Navigate to config folder
cd /var/www/html/police-lms-v15/config

# 2. Open db.php file
nano db.php

# File opens in text editor
```

**Using FTP/File Manager:**
1. Navigate to `/var/www/html/police-lms-v15/config/`
2. Right-click `db.php`
3. Select "Edit" or "Open with Text Editor"

### Step 3.2: Update Database Credentials

Find these lines in `db.php` (around lines 5-8):

```php
$DB_HOST = getenv('POLICE_LMS_DB_HOST') ?: 'localhost';
$DB_USER = getenv('POLICE_LMS_DB_USER') ?: 'police_lms_app';
$DB_PASS = getenv('POLICE_LMS_DB_PASS') ?: '';
$DB_NAME = getenv('POLICE_LMS_DB_NAME') ?: 'police_lms';
```

**Change to:**
```php
$DB_HOST = 'localhost';                    // Usually localhost
$DB_USER = 'police_lms_app';              // Or your MySQL username
$DB_PASS = 'your_mysql_password';         // Your MySQL password
$DB_NAME = 'police_lms';                  // Database name
```

### Step 3.3: Common Database Configurations

**For cPanel Users:**
```php
$DB_HOST = 'localhost';
$DB_USER = 'cpaneluser_police_lms';       // Usually cpaneluser_dbname
$DB_PASS = 'your_generated_password';
$DB_NAME = 'cpaneluser_police_lms';
```

**For Local Development:**
```php
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';                             // Usually empty for local
$DB_NAME = 'police_lms';
```

**For Remote Database:**
```php
$DB_HOST = 'db.example.com';              // Your database server
$DB_USER = 'remote_user';
$DB_PASS = 'remote_password';
$DB_NAME = 'police_lms';
```

### Step 3.4: Save Changes

**In Nano Editor:**
```bash
# 1. Press Ctrl + X (to exit)
# 2. Press Y (to confirm save)
# 3. Press Enter (to confirm filename)
```

**In Text Editor (FTP/File Manager):**
- Click "Save" button
- Confirm save

---

## STEP 4: SET FILE PERMISSIONS

⚠️ **IMPORTANT:** File permissions control who can access and modify files.

### Step 4.1: Set Correct Permissions (SSH)

```bash
# Navigate to installation directory
cd /var/www/html/police-lms-v15

# 1. Set all files to 644 (read-write owner, read others)
find . -type f -exec chmod 644 {} \;

# 2. Set all directories to 755 (full owner, read-execute others)
find . -type d -exec chmod 755 {} \;

# 3. Secure config files to 600 (read-write owner only)
chmod 600 config/db.php
chmod 600 config/auth.php
chmod 600 config/security_headers.php

# 4. Create logs directory (if needed)
mkdir -p logs
chmod 755 logs

# 5. Verify permissions
ls -la config/db.php
# Should show: -rw------- (600 permissions)

ls -la auth/login.php
# Should show: -rw-r--r-- (644 permissions)
```

### Step 4.2: Set Permissions via FTP/File Manager

1. **For config folder:**
   - Right-click `config` folder
   - Select "Permissions" or "Properties"
   - Set to: **755** (rwxr-xr-x)

2. **For config files (db.php, auth.php, etc.):**
   - Right-click each file
   - Select "Permissions" or "Properties"
   - Set to: **600** (rw-------)

3. **For all other folders:**
   - Right-click folder
   - Select "Permissions"
   - Set to: **755** (rwxr-xr-x)

4. **For all other files:**
   - Right-click file
   - Select "Permissions"
   - Set to: **644** (rw-r--r--)

### Step 4.3: Verify Permissions

```bash
# Check key files
ls -la /var/www/html/police-lms-v15/config/db.php
# Should show: -rw------- (600)

ls -la /var/www/html/police-lms-v15/auth/login.php
# Should show: -rw-r--r-- (644)

ls -la /var/www/html/police-lms-v15/
# Directories should show: drwxr-xr-x (755)
```

---

## STEP 5: VERIFY INSTALLATION

### Step 5.1: Check Database Connection

**Create a test file (temporary):**

```bash
# 1. Create test file
cat > /var/www/html/police-lms-v15/test-db.php << 'EOF'
<?php
require_once 'config/db.php';

echo "<h2>Database Connection Test</h2>";

if ($conn) {
    echo "<p style='color: green;'>✅ Database connected successfully!</p>";
    
    // Test query
    $result = $conn->query("SELECT COUNT(*) as table_count FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'police_lms'");
    $row = $result->fetch_assoc();
    
    echo "<p>Tables found: " . $row['table_count'] . "</p>";
    
    // Check if users table has data
    $users = $conn->query("SELECT COUNT(*) as user_count FROM users");
    $user_row = $users->fetch_assoc();
    echo "<p>Users in database: " . $user_row['user_count'] . "</p>";
    
} else {
    echo "<p style='color: red;'>❌ Database connection failed!</p>";
    echo "<p>Error: " . $conn->connect_error . "</p>";
}
?>
EOF

# 2. Access in browser
# Go to: https://your-domain/police-lms-v15/test-db.php

# 3. Delete test file when done
rm /var/www/html/police-lms-v15/test-db.php
```

### Step 5.2: Check File Structure

```bash
# Verify all key files exist
test -f /var/www/html/police-lms-v15/auth/login.php && echo "✅ login.php found"
test -f /var/www/html/police-lms-v15/config/db.php && echo "✅ db.php found"
test -f /var/www/html/police-lms-v15/dashboard.php && echo "✅ dashboard.php found"
test -f /var/www/html/police-lms-v15/assets/css/style.css && echo "✅ style.css found"
test -f /var/www/html/police-lms-v15/assets/js/app.js && echo "✅ app.js found"
```

### Step 5.3: Verify Database Tables

```bash
# Connect to MySQL
mysql -u root -p police_lms

# At MySQL prompt, check tables:
SHOW TABLES;

# Verify users table
SELECT COUNT(*) FROM users;
# Should return: 1 (the super admin user)

# Exit
EXIT;
```

---

## STEP 6: FIRST LOGIN

### Step 6.1: Access the Login Page

1. **Open your browser**
2. **Go to URL:**
   ```
   https://your-domain.com/police-lms-v15/auth/login.php
   ```

   **Note:** Replace `your-domain.com` with your actual domain

3. **Expected Result:**
   - Login page should display with glassmorphism design
   - You should see:
     - "Police LMS" logo
     - Leave Management System subtitle
     - NIC input field
     - Password input field
     - Security Code (math problem) field
     - Sign In button

### Step 6.2: Enter Default Credentials

Fill in the login form:

```
NIC: 000000000V
Password: password
Security Code: [Solve the math problem shown, e.g., 3 + 5 = 8]
```

### Step 6.3: Handle "Change Password" Requirement

1. **First login forces password change**
2. **You'll be redirected to:**
   ```
   https://your-domain.com/police-lms-v15/auth/change_password.php
   ```

3. **Enter new password:**
   - Current Password: `password`
   - New Password: [Create strong password]
   - Confirm Password: [Repeat new password]

4. **Password Requirements:**
   - Minimum 8 characters
   - At least 1 uppercase letter (A-Z)
   - At least 1 lowercase letter (a-z)
   - At least 1 number (0-9)
   - At least 1 special character (!@#$%^&*)

   **Example Strong Password:**
   ```
   MySecurePass@123
   ```

5. **Click "Update Password"**

### Step 6.4: Access Dashboard

1. **You should be redirected to:**
   ```
   https://your-domain.com/police-lms-v15/dashboard.php
   ```

2. **Dashboard should show:**
   - Welcome message with your name
   - 4 KPI cards (Total Applications, Approved, Pending, Days Used)
   - Upcoming Leaves section
   - Quick Actions panel
   - Admin panel (if logged in as admin)

3. **Verify CSS is loading:**
   - Page should have gradient background
   - Cards should have glassmorphism effect
   - No broken styling or layout

---

## STEP 7: POST-INSTALLATION SETUP

### Step 7.1: Create MySQL Database User (Security)

⚠️ **Important for production security**

```bash
# 1. Connect to MySQL as root
mysql -u root -p

# 2. Create new user (at MySQL prompt):
CREATE USER 'police_lms_app'@'localhost' IDENTIFIED BY 'strong_secure_password_here';

# 3. Grant limited permissions:
GRANT SELECT, INSERT, UPDATE, DELETE ON police_lms.* TO 'police_lms_app'@'localhost';

# 4. Apply changes:
FLUSH PRIVILEGES;

# 5. Exit
EXIT;

# 6. Update config/db.php with new credentials:
# $DB_USER = 'police_lms_app';
# $DB_PASS = 'strong_secure_password_here';
```

### Step 7.2: Create Additional Admin Users

1. **Login to dashboard**
2. **Click on "Admin" menu** (top right)
3. **Click "User Management"**
4. **Click "Add User" button**
5. **Fill in user details:**
   - NIC: User's national ID
   - Full Name: User's full name
   - Rank: User's police rank
   - Role: Select appropriate role
   - Station: Select station
   - Phone: User's phone number
   - Email: User's email

6. **Click "Add User"**
7. **Share temporary password with user**
8. **User changes password on first login**

### Step 7.3: Configure Security Headers

1. **Check HTTPS is enabled:**
   - URL should start with `https://`
   - Browser should show padlock icon

2. **Security headers are automatically set in:**
   ```
   config/security_headers.php
   ```

3. **Verify headers (using browser developer tools):**
   - Press F12 (or right-click → Inspect)
   - Go to "Network" tab
   - Reload page
   - Click on main document
   - Check "Response Headers" should show:
     - `X-Content-Type-Options: nosniff`
     - `X-Frame-Options: SAMEORIGIN`
     - `Strict-Transport-Security: max-age=31536000`

### Step 7.4: Configure Backups

```bash
# 1. Create backup script
cat > /var/www/html/backup-police-lms.sh << 'EOF'
#!/bin/bash

BACKUP_DIR="/backups"
DATE=$(date +"%Y%m%d_%H%M%S")
DB_NAME="police_lms"
DB_USER="root"
DB_PASS="your_password"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup database
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > $BACKUP_DIR/police_lms_db_$DATE.sql

# Backup files
tar -czf $BACKUP_DIR/police_lms_files_$DATE.tar.gz /var/www/html/police-lms-v15/

echo "Backup completed: $DATE"
EOF

# 2. Make script executable
chmod +x /var/www/html/backup-police-lms.sh

# 3. Schedule daily backup (crontab)
# crontab -e
# Add line: 0 2 * * * /var/www/html/backup-police-lms.sh
# This runs backup every day at 2 AM
```

---

## TROUBLESHOOTING

### Issue 1: "Database Connection Failed"

**Error Message:**
```
Database connection error. Please contact administrator.
```

**Solutions:**

1. **Check MySQL is running:**
   ```bash
   systemctl status mysql
   # If not running:
   systemctl start mysql
   ```

2. **Verify credentials in config/db.php:**
   ```bash
   nano /var/www/html/police-lms-v15/config/db.php
   # Check these lines:
   # $DB_HOST = 'localhost';
   # $DB_USER = correct username
   # $DB_PASS = correct password
   # $DB_NAME = 'police_lms';
   ```

3. **Test MySQL connection:**
   ```bash
   mysql -u your_user -p -h localhost -D police_lms
   # Enter password when prompted
   # Should show: mysql>
   ```

4. **Check database exists:**
   ```bash
   mysql -u root -p -e "SHOW DATABASES;"
   # Should see 'police_lms' listed
   ```

### Issue 2: "Login Failed - Invalid Credentials"

**Solutions:**

1. **Verify database has users:**
   ```bash
   mysql -u root -p police_lms
   SELECT * FROM users;
   # Should show user with NIC: 000000000V
   ```

2. **Check user account status:**
   ```bash
   SELECT id, nic, full_name, account_status FROM users;
   # Status should be 'ACTIVE'
   ```

3. **Reset admin password:**
   ```bash
   mysql -u root -p police_lms
   # Password hash for 'password':
   UPDATE users SET password_hash='$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36P4rWG' WHERE nic='000000000V';
   EXIT;
   ```

### Issue 3: "CSS Not Loading - Page Looks Broken"

**Solutions:**

1. **Check file permissions:**
   ```bash
   ls -la /var/www/html/police-lms-v15/assets/css/style.css
   # Should show: -rw-r--r-- (644)
   ```

2. **Verify CSS file exists:**
   ```bash
   test -f /var/www/html/police-lms-v15/assets/css/style.css && echo "File exists"
   ```

3. **Check file size:**
   ```bash
   ls -lh /var/www/html/police-lms-v15/assets/css/style.css
   # Should be around 6-8 KB
   ```

4. **Clear browser cache:**
   - Press Ctrl+Shift+Delete (or Cmd+Shift+Delete on Mac)
   - Clear cache
   - Reload page

### Issue 4: "Session Not Found" or "Session Timeout"

**Solutions:**

1. **Check PHP session directory:**
   ```bash
   ls -la /var/lib/php/sessions/
   # Should have files starting with 'sess_'
   ```

2. **Fix permissions:**
   ```bash
   chmod 1733 /var/lib/php/sessions/
   ```

3. **Check PHP session settings:**
   ```bash
   php -i | grep session
   # Look for:
   # session.save_path => /var/lib/php/sessions
   # session.gc_maxlifetime => 1440 (24 minutes)
   ```

### Issue 5: "Permission Denied" When Accessing Files

**Solutions:**

```bash
# 1. Check ownership
ls -la /var/www/html/police-lms-v15/

# 2. Fix ownership (if needed)
chown -R www-data:www-data /var/www/html/police-lms-v15/

# 3. Fix permissions
find /var/www/html/police-lms-v15 -type f -exec chmod 644 {} \;
find /var/www/html/police-lms-v15 -type d -exec chmod 755 {} \;
chmod 600 /var/www/html/police-lms-v15/config/*.php
```

### Issue 6: "Database Import Failed"

**Solutions:**

1. **Check file path:**
   ```bash
   test -f /var/www/html/police-lms-v15/database_setup.sql && echo "File exists"
   ```

2. **Check file size:**
   ```bash
   ls -lh /var/www/html/police-lms-v15/database_setup.sql
   # Should be around 9-10 KB
   ```

3. **Import with verbose output:**
   ```bash
   mysql -u root -p -v < /var/www/html/police-lms-v15/database_setup.sql
   # Shows each query being executed
   ```

4. **Check MySQL error log:**
   ```bash
   tail -50 /var/log/mysql/error.log
   # Shows recent MySQL errors
   ```

---

## VERIFICATION CHECKLIST

After installation, verify everything:

- [ ] Files extracted to `/var/www/html/police-lms-v15/`
- [ ] Database `police_lms` created with 13+ tables
- [ ] Config file `config/db.php` updated with correct credentials
- [ ] File permissions set correctly (644 files, 755 directories)
- [ ] Login page accessible at `https://your-domain/police-lms-v15/auth/login.php`
- [ ] Can login with default credentials
- [ ] Dashboard loads correctly with CSS styling
- [ ] Password change page works
- [ ] Logout functionality works
- [ ] No errors in browser console (F12)
- [ ] No errors in server logs

---

## NEXT STEPS

After successful installation:

1. **Create additional admin users** - See Step 7.2
2. **Configure backup strategy** - See Step 7.4
3. **Set up monitoring** - Monitor error logs
4. **Create user accounts** - Add staff to system
5. **Configure email (optional)** - For notifications
6. **Schedule backups** - Automated daily backups
7. **Train users** - Get staff trained on system
8. **Go live** - Deploy to production

---

## GETTING HELP

### Check These Files First:

1. **README.md** - System overview
2. **INSTALLATION.md** - Installation guide
3. **DEPLOYMENT_GUIDE.md** - Production deployment
4. **INDEX.md** - Technical specifications

### Check Error Logs:

```bash
# PHP errors
tail -50 /var/log/php-error.log

# MySQL errors
tail -50 /var/log/mysql/error.log

# Web server errors (Apache)
tail -50 /var/log/apache2/error.log

# Web server errors (Nginx)
tail -50 /var/log/nginx/error.log
```

---

## SUCCESS!

🎉 **Congratulations!**

Your Police LMS v15 is now installed and ready to use.

**What you can do now:**
- ✅ Login with default credentials
- ✅ Change your password
- ✅ View the dashboard
- ✅ Create additional users
- ✅ Configure the system

**Next:** Follow Step 7 (Post-Installation Setup) for security hardening and additional configuration.

---

**Installation Date:** [Today's Date]  
**Version:** 15.0  
**Status:** ✅ Complete

Happy deploying! 🚀
